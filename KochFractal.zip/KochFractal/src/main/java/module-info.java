module kochfractal {
    requires javafx.controls;

    exports fun3kochfractalfx;
}