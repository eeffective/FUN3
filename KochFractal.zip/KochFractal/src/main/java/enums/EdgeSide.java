package enums;

public enum EdgeSide {
    LEFT,
    BOTTOM,
    RIGHT
}
