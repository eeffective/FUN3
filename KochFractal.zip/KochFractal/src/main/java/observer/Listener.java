package observer;

public interface Listener {
    void update(Object object);
}

